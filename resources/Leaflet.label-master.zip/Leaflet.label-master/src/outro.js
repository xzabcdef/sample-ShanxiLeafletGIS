	return LeafletLabel;
}, window));
